﻿(function (window, $, ko, PDF, undefined) {
    "use strict";

    var componentIdentifier = "RelatedContent";

    PDF.ViewModels[componentIdentifier] = function (promise, el, params) {
        var viewModel = function ($) {
            var self = Object.create(PDF.BaseViewModel);
            self.relatedContentList = ko.observableArray();
            self.moreUrl = ko.observable(params.MoreUrl);
            self.componentKey = ko.observable(params.ComponentKey);
            self.getDataContextUrlFn = PDF.Utils.GetContextUrlFn(componentIdentifier, 'dataContextBaseUrl');

            self.LoadRelatedContent = function () {
                var url = self.getDataContextUrlFn('api/pdf/Search/GetRelatedContent');
                return $.getJSON(url, { query: params.Query, filter: params.Filter == null ? '' : params.Filter, culture: params.Culture, relatedTo: params.RelatedTo, componentKey: params.ComponentKey }, function (data) {
                    promise.done(function () {
                        self.relatedContentList(data);
                    });
                });
            };
            return self;
        }($);

        promise.await([
            viewModel.ExtendUIStrings("PDF.RelatedContent.UIStrings." + params.ComponentKey),
            viewModel.ExtendContentModel("PDF.RelatedContent.Configuration." + params.ComponentKey, "Config"),
            viewModel.LoadRelatedContent()
        ], viewModel);
    };
})(window, jQuery, ko, PDF);